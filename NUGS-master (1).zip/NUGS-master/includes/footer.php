<footer>
	<div class="container-fluid">
		<p class="text-center pt-4">&copy; <?php echo date('Y') ?> NUGS UKRAINE. Powered by BrandAfrik</p>
	</div>
</footer>